import os
os.system("streamlit run streamlit_writer_tool.py")
